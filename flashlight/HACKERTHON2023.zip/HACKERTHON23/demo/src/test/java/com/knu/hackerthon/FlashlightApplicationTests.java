package com.knu.hackerthon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlashlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
