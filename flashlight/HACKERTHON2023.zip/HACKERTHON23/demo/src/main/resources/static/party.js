function changeContent1(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "A 후보\n전과 1범\n작가, 교수 출신";
    }
}

function changeContent2(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "B 후보\n전과 2범\n변호사 출신";
    }
}

function changeContent3(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "C 후보\n전과 3범\n음주운전 전과\n변호사 출신";
    }
}

function changeContent4(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "D 후보\n전과 1범\n노동운동가 출신";
    }
}

function changeContent5(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "E 후보\n전과 없음\n검사 출신";
    }
}

function changeContent6(element, onHover) {
    if (onHover) {
      element.innerText = "후보자 확인하기";
    } else {
      element.innerText = "F 후보\n전과 3범\n법학과 출신";
    }
}