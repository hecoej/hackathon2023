package com.knu.hackerthon;
import com.knu.hackerthon.Pledge;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class FlashlightDto {

    private Integer id;
    private Integer num;
    private String nameCol;
    private String groupCol;
    private String category1;
    private String category2;
    private String line;

    public Pledge toEntity(){
        Pledge pledge = Pledge.builder()
                .id(id)
                .num(num)
                .nameCol(nameCol)
                .groupCol(groupCol)
                .category1(category1)
                .category2(category2)
                .line(line)
                .build();
        return pledge;
    }

    @Builder
    public FlashlightDto(Integer id, Integer num, String nameCol, String groupCol, String category1, String category2, String line) {
        this.id = id;
        this.num = num;
        this.nameCol = nameCol;
        this.groupCol = groupCol;
        this.category1 = category1;
        this.category2 = category2;
        this.line = line;
    }
}