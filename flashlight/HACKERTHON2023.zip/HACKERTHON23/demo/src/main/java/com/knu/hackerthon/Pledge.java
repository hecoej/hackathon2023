package com.knu.hackerthon;

import jakarta.persistence.*;
import jdk.jshell.Snippet;
import lombok.*;

@Data
@Entity
@Getter
@Setter
@Table(name = "blind_pledge")
@NoArgsConstructor(access = AccessLevel.PROTECTED)

public class Pledge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer num;
    private String nameCol;
    private String groupCol;
    private String category1;
    private String category2;
    private String line;

    @Builder
    public Pledge(Integer id, Integer num, String nameCol, String groupCol, String category1, String category2, String line) {
        this.id = id;
        this.num = num;
        this.nameCol = nameCol;
        this.groupCol = groupCol;
        this.category1 = category1;
        this.category2 = category2;
        this.line = line;
    }
}
