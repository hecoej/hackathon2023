package com.knu.hackerthon;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

import java.util.List;

@Controller
public class FlashlightController {
    private final FlashlightService flashlightService;

    // 생성자를 통한 주입
    @Autowired
    public FlashlightController(FlashlightService flashlightService) {
        this.flashlightService = flashlightService; // FlashlightService 주입
    }
    @GetMapping("/index")
    public String index() {
        return "index.html";
    }

    @GetMapping("/info")
    public String info() {
        return "info.html";
    }

    @GetMapping("/party")
    public String party() {
        return "party.html";
    }

    @GetMapping("/polls")
    public String polls() {
        return "polls.html";
    }

    @GetMapping("/poti")
    public String poti() {
        return "poti.html";
    }

    @GetMapping("/roadmap")
    public String roadmap() {
        return "roadmap_main.html";
    }

    @GetMapping("/pledge")
    public String pledge() {
        return "pledge.html";
    }

    @GetMapping("/pledge/economy")
    public String redirectToEconomyPage() {
        return "economy.html";
    }

    @GetMapping("/roadmap/roadmap_1")
    public String roadmap1() {
        return "roadmap_1.html";
    }
    @GetMapping("/roadmap/roadmap_2")
    public String roadmap2() {
        return "roadmap_2.html";
    }

    @GetMapping("/party/party1/pledgeList")
    public String showPledgeList(@org.jetbrains.annotations.NotNull Model model) {
        List<FlashlightDto> flashlightDtoList = flashlightService.getPledgelist();

        // 모델에 데이터 추가
        model.addAttribute("pledgeList", flashlightDtoList);

        // HTML 페이지 반환
        return "pledgelist.html";
    }
}
