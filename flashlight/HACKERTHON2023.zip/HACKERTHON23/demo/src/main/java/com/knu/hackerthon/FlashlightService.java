package com.knu.hackerthon;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@AllArgsConstructor
@Service
public class FlashlightService {

    private final FlashlightRepository flashlightRepository;
    @Transactional
    public List<FlashlightDto> getPledgelist() {
        List<Pledge> pledges = flashlightRepository.findAll();
        List<FlashlightDto> flashlightDtoList = new ArrayList<>();

        for (Pledge pledge : pledges) {
            FlashlightDto flashlightDto = FlashlightDto.builder()
                    .id(pledge.getId())
                    .num(pledge.getNum())
                    .nameCol(pledge.getNameCol())
                    .groupCol(pledge.getGroupCol())
                    .category1(pledge.getCategory1())
                    .category2(pledge.getCategory2())
                    .line(pledge.getLine())
                    .build();
            flashlightDtoList.add(flashlightDto);
        }
        return flashlightDtoList;
    }
}